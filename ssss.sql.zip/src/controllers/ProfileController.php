<?php

require_once 'AppController.php';
require_once __DIR__ . '/../repository/UserRepository.php';

class ProfileController extends AppController {
    private $userRepository;

    public function __construct() {
        parent::__construct();
        $this->userRepository = new UserRepository();
    }

    public function profile() {
        if (!isset($_SESSION['user'])) {
            header("Location: /login");
            exit();
        }

        $user = $this->userRepository->getUserByEmail($_SESSION['user']);

        $this->render('profile', ['user' => $user]);
    }
}
