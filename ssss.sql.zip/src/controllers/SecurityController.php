<?php

require_once 'AppController.php';
require_once __DIR__ . '/../repository/UserRepository.php';

class SecurityController extends AppController {
    private $userRepository;

    public function __construct() {
        parent::__construct();
        $this->userRepository = new UserRepository();
    }

    public function login() {
        $error = null;
    
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $email = $_POST['email'];
            $password = $_POST['password'];
    
            $user = $this->userRepository->getUserByEmail($email);
    
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user'] = $user['email'];
                $_SESSION['user_id'] = $user['id']; 
                $_SESSION['nickname'] = $user['nickname']; // ✅ Dodajemy nickname do sesji
                $_SESSION['role'] = $this->userRepository->getUserRole($email);
    
                header("Location: /dashboard");
                exit();
            } else {
                $error = "Invalid email or password!";
            }
        }
    
        $this->render('login', ['error' => $error]);
    }
    
    public function logout() {
        session_unset();
        session_destroy();
        header("Location: /login");
        exit();
    }

    public function register() {
        $error = null;

        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $email = $_POST['email'];
            $password = $_POST['password'];
            $confirmPassword = $_POST['confirm_password'];
            $nickname = $_POST['nickname']; // ✅ Dodajemy nickname

            if ($password !== $confirmPassword) {
                $error = "Passwords do not match!";
            } else {
                $existingUser = $this->userRepository->getUserByEmail($email);

                if ($existingUser) {
                    $error = "Email already in use!";
                } else {
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $this->userRepository->addUser($email, $hashedPassword, $nickname); // ✅ Dodajemy nickname

                    header("Location: /login");
                    exit();
                }
            }
        }

        $this->render('register', ['error' => $error]);
    }
}
