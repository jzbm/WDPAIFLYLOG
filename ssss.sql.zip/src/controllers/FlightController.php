<?php

require_once 'AppController.php';
require_once __DIR__ . '/../repository/FlightRepository.php';

class FlightController extends AppController {
    private $flightRepository;

    public function __construct() {
        parent::__construct();
        $this->flightRepository = new FlightRepository();
    }

    public function add_flight() { // ✅ snake_case
        if (!isset($_SESSION['user'])) {
            header("Location: /login");
            exit();
        }
    
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $departureAirport = $_POST['departure_airport'];
            $landingAirport = $_POST['landing_airport'];
            $aircraft = $_POST['aircraft'];
            $departureTime = $_POST['departure_time'];
            $landingTime = $_POST['landing_time'];
    
            if (empty($departureAirport) || empty($landingAirport) || empty($aircraft) || empty($departureTime) || empty($landingTime)) {
                $error = "All fields are required!";
            } else {
                // ✅ Konwersja formatu daty na kompatybilny z PostgreSQL
                $departureTime = date('Y-m-d H:i:s', strtotime($departureTime));
                $landingTime = date('Y-m-d H:i:s', strtotime($landingTime));
    
                $departureTimestamp = strtotime($departureTime);
                $landingTimestamp = strtotime($landingTime);
    
                if ($landingTimestamp <= $departureTimestamp) {
                    $error = "Landing time must be after departure time!";
                } else {
                    // ✅ Obliczanie czasu lotu w minutach (jako integer)
                    $flightTime = (int)(($landingTimestamp - $departureTimestamp) / 60);
    
                    $userId = $this->get_user_id();
                    $this->flightRepository->addFlight($userId, $departureAirport, $landingAirport, $aircraft, $flightTime, $departureTime, $landingTime);
    
                    header("Location: /profile");
                    exit();
                }
            }
        }
    }

    public function get_total_flight_time() { // ✅ snake_case
        $userId = $this->get_user_id();
        return $this->flightRepository->getTotalFlightTimeByUserId($userId);
    }

    private function get_user_id() { // ✅ snake_case
        $stmt = $this->flightRepository->getDatabase()->prepare('
            SELECT id FROM users WHERE email = :email
        ');
        $stmt->bindParam(':email', $_SESSION['user'], PDO::PARAM_STR);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) {
            die("User not found!");
        }

        return $user['id'] ?? null;
    }

    public function profile() {
        $userId = $this->get_user_id();
        $flights = $this->flightRepository->getFlightsByUserId($userId);
        $totalFlightTime = $this->flightRepository->getTotalFlightTimeByUserId($userId);
    
        $this->render('profile', [
            'flights' => $flights,
            'totalFlightTime' => $totalFlightTime
        ]);
    }
}
