<?php

class User {
    private $id;
    private $email;
    private $password;
    private $nickname;
    private $roleId;

    public function __construct(
        int $id,
        string $email,
        string $password,
        string $nickname,
        int $roleId
    ) {
        $this->id = $id;
        $this->email = $email;
        $this->password = $password;
        $this->nickname = $nickname;
        $this->roleId = $roleId;
    }

    // Getters
    public function getId(): int
    {
        return $this->id;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function getNickname(): string
    {
        return $this->nickname;
    }

    public function getRoleId(): int
    {
        return $this->roleId;
    }

    // Setters
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    public function setNickname(string $nickname): void
    {
        $this->nickname = $nickname;
    }

    public function setRoleId(int $roleId): void
    {
        $this->roleId = $roleId;
    }
}
