<?php

class Post {
    private $id;
    private $userId;
    private $title;
    private $content;
    private $nickname;
    private $image;

    public function __construct($id, $userId, $title, $content, $nickname, $image = null) {
        $this->id = $id;
        $this->userId = $userId;
        $this->title = $title;
        $this->content = $content;
        $this->nickname = $nickname;
        $this->image = $image;
    }

    public function getId() {
        return $this->id;
    }

    public function getUserId() {
        return $this->userId;
    }

    public function getTitle() {
        return $this->title;
    }

    public function getContent() {
        return $this->content;
    }

    public function getNickname() {
        return $this->nickname;
    }
    
    public function getImage() {
        return $this->image;
    }
    public function setComments(array $comments) {
        $this->comments = $comments;
    }
    
    public function getComments() {
        return $this->comments;
    }
}
