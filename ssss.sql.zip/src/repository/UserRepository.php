<?php

require_once __DIR__ . '/Database.php';

class UserRepository {
    private $database;

    public function __construct() {
        $this->database = Database::getInstance()->connect();
    }

    // ✅ Pobieranie użytkownika po emailu (z nickname i role_id)
    public function getUserByEmail($email) {
        $stmt = $this->database->prepare('
            SELECT id, email, password, nickname, role_id 
            FROM users 
            WHERE email = :email
        ');
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // ✅ Dodanie użytkownika (z nickname)
    public function addUser($email, $password, $nickname) {
        $stmt = $this->database->prepare('
            INSERT INTO users (email, password, nickname) 
            VALUES (:email, :password, :nickname)
        ');
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
        $stmt->bindParam(':nickname', $nickname, PDO::PARAM_STR);
        $stmt->execute();
    }

    // ✅ Pobieranie roli użytkownika po emailu
    public function getUserRole($email) {
        $stmt = $this->database->prepare('
            SELECT role_id 
            FROM users 
            WHERE email = :email
        ');
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user['role_id'] ?? null;
    }

    // ✅ Pobieranie listy użytkowników (do wysyłania wiadomości)
    public function getAllUsers() {
        $stmt = $this->database->prepare('
            SELECT id, nickname FROM users
        ');
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
