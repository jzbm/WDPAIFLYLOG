<?php

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/../models/Post.php';

class PostRepository {

    private $database;

    public function __construct() {
        $this->database = Database::getInstance()->connect(); 
    }

    public function add_Post($userId, $title, $content, $imagePath = null) {
        $stmt = $this->database->prepare('
            INSERT INTO posts (user_id, title, content, image) 
            VALUES (:userId, :title, :content, :image)
        ');
    
        $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':title', $title, PDO::PARAM_STR);
        $stmt->bindParam(':content', $content, PDO::PARAM_STR);
        $stmt->bindParam(':image', $imagePath, PDO::PARAM_STR);
        $stmt->execute();
    }
    

    public function get_Posts() {
        $stmt = $this->database->prepare('
            SELECT p.id, p.user_id, p.title, p.content, p.image, u.nickname 
            FROM posts p 
            JOIN users u ON p.user_id = u.id 
            ORDER BY p.id DESC
        ');
        $stmt->execute();
    
        $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        $result = [];
        foreach ($posts as $post) {
            $result[] = new Post(
                $post['id'],
                $post['user_id'],
                $post['title'],
                $post['content'],
                $post['nickname'],
                $post['image'] ?? null
            );
        }
    
        return $result;
    }
    
}
